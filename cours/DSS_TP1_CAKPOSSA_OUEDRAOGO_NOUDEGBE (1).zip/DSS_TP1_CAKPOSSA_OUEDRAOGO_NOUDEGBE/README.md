# Digital Social Score — livrable TP1

**Équipe** : CAKPOSSA Jean-Philippe, OUEDRAOGO Eliana, NOUDEGBE Situ
**Cours** : Déploiement de solutions IA et cybersécurité — ESIGELEC, novembre 2026
**Dépôt** : https://github.com/elSam22/depl_ai_cyber. Code en service sur GKE : branche `ci`, déployée le 16 novembre 2026.

API qui reçoit un commentaire et renvoie un score de toxicité de 0 à 100. Le texte est anonymisé avant le modèle (regex + spaCy NER) et n'est jamais stocké. Modèle DistilBERT, déployé sur GKE Autopilot à Paris, en HTTPS, derrière une clé d'API.

## Contenu

| Élément | Livrable du sujet |
|---|---|
| `Rapport_DSS_TP1.pdf` / `.docx` | Rapport complet : choix justifiés, mesures, sécurité, RGPD, charge, supervision, architecture |
| `01_registre_RGPD/` | Registre RGPD (art. 30), version 1.1 relue contre le code |
| `02_architecture/` | Schéma d'architecture cloud (`.png`) et son script source (`.py`) ; légende et texte explicatif : rapport, § 8 |
| `03_code/` | API documentée (`api/`), manifestes Kubernetes (`api/k8s/`), scripts de déploiement (`api/deploy/`), tests (`api/tests/`), notebooks, front de démonstration |
| `04_tests_charge/` | Rapport de simulation de charge (`RAPPORT.md`), scripts Locust, CSV bruts, courbes |
| `05_supervision/` | Tableau de bord Grafana (`grafana_dashboard.json`), règles d'alerte (`alertes.yaml`), captures (`images/`), registre des incidents (`INCIDENTS.md`), script d'analyse des journaux |
| `06_grille_tests/` | Grille de tests sécurité / stress / failover / supervision |
| Exemples de requêtes et de réponses | Rapport, § 4.4 |

## Relancer

```bash
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r 03_code/requirements.txt

# API locale + front (choix du modèle, détail des étapes) : nécessite models/ (notebooks)
cd 03_code && ../.venv/bin/uvicorn api.main_local:app --port 8000   # http://127.0.0.1:8000/

# Tests de l'API (modèle factice, sans GPU)
cd 03_code/api && pytest -v

# Déploiement GKE (une fois, puis à chaque version)
PROJECT_ID=<projet> bash api/deploy/gke_setup.sh
python api/export_model.py --type distilbert
PROJECT_ID=<projet> bash api/deploy/deploy_gke.sh
```

Commandes complètes (données, entraînement, tests de charge) : rapport, annexe A.

## À savoir

- **Aucun secret** dans ce livrable : `<domaine>`, `<CLE_API>` et `<projet>` remplacent les vraies valeurs. Les poids du modèle (bucket privé) et le jeu de données (Kaggle, *Toxic Comment Classification Challenge*) ne sont pas inclus.
- **Périmètre TP1 / TP2.** Le code est celui en service. `defense_extraction.py`, `limiteur_debit.py` et `protection.py` sont conservés parce que `main.py` les importe. Les travaux propres au TP2 (dossier `attack/`, pipeline DevSecOps, model card IA Act) ne sont pas dans ce livrable.
- **Grille de tests.** `06_grille_tests/GRILLE_TESTS.md` est datée du 12 novembre. Les résultats à jour (fermeture de `/docs`, limitation de débit en service, test anti brute-force) sont dans le rapport, § 7.3.
